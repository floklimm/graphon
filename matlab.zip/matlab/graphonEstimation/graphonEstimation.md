# graphonEstimation

These estimators are not produced by ourselves but rather from other sources. At the moment the sort-and-smooth algorithm and a matrix-completion approach are available.

For more approaches see the [Airoldi Lab](https://github.com/airoldilab/).
